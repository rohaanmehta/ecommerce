
 $(document).ready(function(){
      $('.items').slick({
        dots: false,
        infinite: true,
        speed: 800,
        slidesToShow: 5,
        slidesToScroll: 1,
        prevArrow:"<img style='width:30px;height:30px;z-index: 100;margin-left: 50px;' class='slick-custom-img a-left control-c prev slick-prev' src='/testi/images/leftarrow.png'>",
        nextArrow:"<img style='width:30px;height:30px;z-index: 100;margin-right: 50px;' class='slick-custom-img a-right control-c prev slick-next' src='/testi/images/rightarrow.png'>",
        responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            infinite: true,
            // dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,        
          }
        }

        ]
      });
    });